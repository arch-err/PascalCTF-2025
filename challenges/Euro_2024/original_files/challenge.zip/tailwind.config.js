/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["src/public/**/*.html", 'views/**/*.{html,ejs}'],
  theme: {
    extend: {},
  },
  plugins: [],
}

